package louis.matutino.com.matutinolabexer4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;

public class AndroidAdapter extends ArrayAdapter{

    private Context context;
    private int resource;

    public AndroidAdapter(Context context, int resource, List objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
    }

    @NonNull
    @Override
    public View getView(int i, View convertView, ViewGroup parent) {
        int logo = getItem(i).getLogo();
        String version = getItem(i).getName();
        String rDate = getItem(i).getrDate();

        //Implement a LayoutInflater
        LayoutInflater inflater = LayoutInflater.from(context);
        //Layout consumed by convertView
        convertView = inflater.inflate(resource, parent, false);

        ImageView img = convertView.findViewById(R.id.ivLogo);
        TextView verName = convertView.findViewById(R.id.tvName);
        TextView verDate = convertView.findViewById(R.id.tvDate);

        img.setImageResource(logo);
        verName.setText(version);
        verDate.setText(rDate);

        return convertView;
    }
}