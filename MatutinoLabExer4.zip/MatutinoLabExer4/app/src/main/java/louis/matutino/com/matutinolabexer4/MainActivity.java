package louis.matutino.com.matutinolabexer4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


/*
   Implement OnItemClickListener interface to get events from phone when list view was clicked
 */
public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    String[] verNames, verDates;
    int[] verLogos = {R.drawable.cupcake, R.drawable.donut, R.drawable.eclair,
            R.drawable.froyo, R.drawable.gingerbread, R.drawable.honeycomb, R.drawable.icecream };
    ListView lstVersions;

    ArrayList<AndroidVersion> versions = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Get String from res folder
        verNames = getResources().getStringArray(R.array.verName);
        verDates = getResources().getStringArray(R.array.rDate);

        for(int i = 0; i < verNames.length; i++){
            versions.add(new AndroidVersion(verLogos[i], verNames[i], verDates[i]));

        }

        //Adapter for activity and list view
        AndroidAdapter adapter = new AndroidAdapter(this, R.layout.item, versions);

        //setting list view component with id of lvAndroid to lstVersions variable
        lstVersions = findViewById(R.id.lvAndroid);

        //1stVersions consumes adapter
        lstVersions.setAdapter(adapter);

        //Set Listener Object
        lstVersions.setOnItemClickListener(this);

    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int i, long id) {
        Toast.makeText(this, verNames[i], Toast.LENGTH_LONG).show();
    }
}